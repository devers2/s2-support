/*
 * {{{ header & license
 * Copyright (c) 2007 Wisconsin Court System
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 2.1
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 * }}}
 */
package com.openhtmltopdf.util;

import java.util.logging.Level;

/**
 * An interface whose implementations log Flying Saucer log messages.
 */
public interface XRLogger {
    void log(String where, Level level, String msg);
    void log(String where, Level level, String msg, Throwable th);
    void setLevel(String logger, Level level);

    boolean isLogLevelEnabled(Diagnostic diagnostic);

    /**
     * Default slow (!) implementation for logging a Diagnostic object.
     *
     * Concrete implementation must/should override it.
     *
     * @param diagnostic
     */
    default void log(Diagnostic diagnostic) {
        if (diagnostic.hasError()) {
            log(diagnostic.getLogMessageId().getWhere(), diagnostic.getLevel(), diagnostic.getFormattedMessage(), diagnostic.getError());
        } else {
            log(diagnostic.getLogMessageId().getWhere(), diagnostic.getLevel(), diagnostic.getFormattedMessage());
        }
    }
}
